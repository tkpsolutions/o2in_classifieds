<div class="footer">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			Developed and Managed By <a target="_blank" href="https://www.thekingphoenix.com">The King Phoenix</a>
		</div>
	</div>
</div>